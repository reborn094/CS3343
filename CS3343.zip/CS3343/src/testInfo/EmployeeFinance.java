package testInfo;

public class EmployeeFinance {

	private double bonus; // finance
	private double stipend; // finance
	
	public double getBonus() 
	{
		return bonus;
	}
	
	public void setBonus(double bonus) 
	{
		this.bonus = bonus;
	}
	
	public double getStipend() 
	{
		return stipend;
	}
	
	public void setStipend(double stipend) 
	{
		this.stipend = stipend;
	}
	
}
